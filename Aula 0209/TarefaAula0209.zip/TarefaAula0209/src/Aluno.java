
import java.util.Vector;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author laboratorio
 */
public class Aluno {
    public String nome;
    public String datanascimento;
    public char sexo;
    public String cpf;
    public String curso;
    public String matricula;
    public String telefone;
    public String rua;
    public String numero;
    public String bairro;
    public String cidade;
    public String cep;
    public String estado; 
    

    public Aluno(String nome, String datanascimento, char sexo, String cpf, String curso, String matricula, String telefone, String rua, String numero, String bairro, String cidade, String cep, String estado) {
        this.nome = nome;
        this.datanascimento = datanascimento;
        this.sexo = sexo;
        this.cpf = cpf;
        this.curso = curso;
        this.matricula = matricula;
        this.telefone = telefone;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.cep = cep;
        this.estado = estado;
    }
    
    @Override
    public String toString() {
        String sexoTexto;
        if (sexo == 'M') {
            sexoTexto = "Masculino";
        } else {
            sexoTexto = "Feminino";
        }
        
        return nome + ";" + datanascimento + ";" + sexoTexto + ";" + cpf + ";" + curso + ";" + matricula + ";" + telefone + ";" + rua + ";" + numero + ";" + bairro + ";" + cidade + ";" + cep + ";" + estado;
    }

    public Object[] obterDados(){
        return new Object[] {nome, datanascimento, sexo, cpf, curso, matricula, telefone, rua, numero, bairro, cidade, cep, estado};
    }
    
    

}
