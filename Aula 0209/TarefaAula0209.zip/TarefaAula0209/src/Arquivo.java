import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author laboratorio
 */
public class Arquivo {

    private FileWriter arqW;
    private BufferedWriter escritor;

    private FileReader arqR;
    private BufferedReader leitor;

    private List<Aluno> listaAlunos;

    public String nomeArquivo;

    public Arquivo(String nomeArquivo) {
        this.nomeArquivo = nomeArquivo;
        listaAlunos = new ArrayList<>();
    }

    public List<Aluno> leArquivo() {
        listaAlunos.clear();

        try {
            arqR = new FileReader(nomeArquivo + ".txt");
            leitor = new BufferedReader(arqR);

            String linha;

            while ((linha = leitor.readLine()) != null) {

                String[] campos = linha.split(";");

                String nome = campos[0];
                String datanascimento = campos[1];
                char sexo = campos[2].charAt(0);
                String cpf = campos[3];
                String curso = campos[4];
                String matricula = campos[5];
                String telefone = campos[6];
                String rua = campos[7];
                String numero = campos[8];
                String bairro = campos[9];
                String cidade = campos[10];
                String cep = campos[11];
                String estado = campos[12]; 

                Aluno a = new Aluno(nome, datanascimento, sexo, cpf, curso, matricula, telefone, rua, numero, bairro, cidade, cep, estado);

                listaAlunos.add(a);
            }

            leitor.close();
            arqR.close();

        } catch (FileNotFoundException e) {

            System.out.println("Arquivo ainda não existe");

        } catch (IOException e) {

            e.printStackTrace();

        }

        return listaAlunos;
    }

    public List<Aluno> getListaAlunos() {
        return listaAlunos;
    }

    public void gravaArquivo() {

        try {
            arqW = new FileWriter(nomeArquivo + ".txt", false);
            escritor = new BufferedWriter(arqW);

            for (Aluno a : listaAlunos) {

                escritor.write(
                        a.nome + ";"
                        + a.datanascimento + ";"
                        + a.sexo + ";" 
                        + a.cpf + ";"
                        + a.curso + ";" 
                        + a.matricula + ";" 
                        + a.telefone + ";" 
                        + a.rua + ";" 
                        + a.numero + ";" 
                        + a.bairro + ";" 
                        + a.cidade + ";" 
                        + a.cep + ";" 
                        + a.estado
                );

                escritor.newLine();
            }

            escritor.close();
            arqW.close();

            System.out.println("Lista salva no arquivo");  
        } 
        catch (IOException e){
            e.printStackTrace();
        }
        
    }
}
