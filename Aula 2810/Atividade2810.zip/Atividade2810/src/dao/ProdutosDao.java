package dao;
import beans.Categoria;
import beans.Produtos;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import atividade2810.conexao.Conexao;

public class ProdutosDao {
    private Conexao conexao;
    private Connection conn;
    
    public ProdutosDao() {
        this.conexao = new Conexao();
        this.conn = (Connection) this.conexao.getConexao();
    }
    
    public void inserir(Produtos produtos) {
        String sql = "INSERT INTO produtos (nome, preco, quantidade, categoria_id) VALUES (?, ?, ?, ?)";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produtos.getNome());
            stmt.setDouble(2, produtos.getPreco());
            stmt.setInt(3, produtos.getQuantidade());
            stmt.setInt(4, produtos.getCategoria_id().getId());

            stmt.execute();
            stmt.close();
            System.out.println("Produto cadastrado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao inserir produtos: " + e.getMessage());
        }
    }
    
    public void editar(Produtos produtos) {
        try {
            String sql = "UPDATE produtos set nome = ?, preco = ?, quantidade = ?, categoria_id = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, produtos.getNome());
            stmt.setDouble(2, produtos.getPreco());
            stmt.setInt(3, produtos.getQuantidade());
            stmt.setInt(4, produtos.getCategoria_id().getId());
            stmt.setInt(5, produtos.getId());
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar produto: " + ex.getMessage());
        }
    }
    
    public void excluir(int id) {
        try {
            String sql = "DELETE FROM produtos WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir produto: " + ex.getMessage());
        }
    }

    public List<Produtos> getProdutos() {
        // CORRIGIDO: mudado de "produto" para "produtos" (no plural)
        String sql = "SELECT * FROM produtos";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            List<Produtos> listaProdutos = new ArrayList();
            
            while(rs.next()) {
                Produtos p = new Produtos();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidade(rs.getInt("quantidade")); // ADICIONADO: para puxar a quantidade corretamente
                
                CategoriaDao cDao = new CategoriaDao();
                Categoria c = cDao.getCategoria(rs.getInt("categoria_id"));
                p.setCategoria_id(c);
                
                listaProdutos.add(p);
            }
            rs.close();
            stmt.close();
            return listaProdutos;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todas os produtos: " + ex.getMessage());
            return null;
        }
    }
    
    public Produtos getProdutos(int id) {
        String sql = "SELECT * FROM produtos WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (!rs.first()) {
                rs.close();
                stmt.close();
                return null; // Retorna null se não encontrar o produto
            }
            
            Produtos p = new Produtos();
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getDouble("preco"));
            p.setQuantidade(rs.getInt("quantidade")); // ADICIONADO: para puxar a quantidade corretamente
            
            CategoriaDao cDao = new CategoriaDao();
            Categoria c = cDao.getCategoria(rs.getInt("categoria_id"));
            p.setCategoria_id(c);
            
            rs.close();
            stmt.close();
            return p;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar produto: " + ex.getMessage());
            return null;
        }
    }
}