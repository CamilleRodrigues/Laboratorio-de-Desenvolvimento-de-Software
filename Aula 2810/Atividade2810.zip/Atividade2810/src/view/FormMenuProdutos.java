package view;

public class FormMenuProdutos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormMenuProdutos.class.getName());

    public FormMenuProdutos() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MenuBarOpcao = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        MenuItemCadastroProduto = new javax.swing.JMenuItem();
        MenuItemEditarExcluirProduto = new javax.swing.JMenuItem();
        MenuItemCadastroCategoria = new javax.swing.JMenuItem();
        MenuItemEditarCategoria = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        MenuItemRelatório = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu1.setText("Arquivo");
        MenuBarOpcao.add(jMenu1);

        jMenu2.setText("Cadastro");

        MenuItemCadastroProduto.setText("Cadastro Produtos");
        MenuItemCadastroProduto.addActionListener(this::MenuItemCadastroProdutoActionPerformed);
        jMenu2.add(MenuItemCadastroProduto);

        MenuItemEditarExcluirProduto.setText("Editar e Excluir Produtos");
        MenuItemEditarExcluirProduto.addActionListener(this::MenuItemEditarExcluirProdutoActionPerformed);
        jMenu2.add(MenuItemEditarExcluirProduto);

        MenuItemCadastroCategoria.setText("Cadastro Categoria");
        MenuItemCadastroCategoria.addActionListener(this::MenuItemCadastroCategoriaActionPerformed);
        jMenu2.add(MenuItemCadastroCategoria);

        MenuItemEditarCategoria.setText("Editar Categoria");
        MenuItemEditarCategoria.addActionListener(this::MenuItemEditarCategoriaActionPerformed);
        jMenu2.add(MenuItemEditarCategoria);

        MenuBarOpcao.add(jMenu2);

        jMenu3.setText("Relatório");

        MenuItemRelatório.setText("Relatório de Categorias");
        MenuItemRelatório.addActionListener(this::MenuItemRelatórioActionPerformed);
        jMenu3.add(MenuItemRelatório);

        jMenuItem1.setText("Relatório de Produtos");
        jMenuItem1.addActionListener(this::jMenuItem1ActionPerformed);
        jMenu3.add(jMenuItem1);

        MenuBarOpcao.add(jMenu3);

        setJMenuBar(MenuBarOpcao);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuItemCadastroProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemCadastroProdutoActionPerformed
        FormCadastroProdutos cadProdutos = new FormCadastroProdutos();
        cadProdutos.setVisible(true);
    }//GEN-LAST:event_MenuItemCadastroProdutoActionPerformed

    private void MenuItemEditarExcluirProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemEditarExcluirProdutoActionPerformed
        FormEditarExcluirProdutos cadProdutos = new FormEditarExcluirProdutos();
        cadProdutos.setVisible(true);
    }//GEN-LAST:event_MenuItemEditarExcluirProdutoActionPerformed

    private void MenuItemCadastroCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemCadastroCategoriaActionPerformed
        FormCadastroCategoria cadCategoria = new FormCadastroCategoria();
        cadCategoria.setVisible(true);
    }//GEN-LAST:event_MenuItemCadastroCategoriaActionPerformed

    private void MenuItemEditarCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemEditarCategoriaActionPerformed
        FormConsultarEditarCategoria cadCategoria = new FormConsultarEditarCategoria();
        cadCategoria.setVisible(true);
    }//GEN-LAST:event_MenuItemEditarCategoriaActionPerformed

    private void MenuItemRelatórioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemRelatórioActionPerformed
        FormRelatorioCategoria cadCategoria = new FormRelatorioCategoria();
        cadCategoria.setVisible(true);
    }//GEN-LAST:event_MenuItemRelatórioActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        FormRelatorioProdutos cadProdutos = new FormRelatorioProdutos();
        cadProdutos.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new FormMenuProdutos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar MenuBarOpcao;
    private javax.swing.JMenuItem MenuItemCadastroCategoria;
    private javax.swing.JMenuItem MenuItemCadastroProduto;
    private javax.swing.JMenuItem MenuItemEditarCategoria;
    private javax.swing.JMenuItem MenuItemEditarExcluirProduto;
    private javax.swing.JMenuItem MenuItemRelatório;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuItem jMenuItem1;
    // End of variables declaration//GEN-END:variables
}
