package atividade2810;
import atividade2810.conexao.Conexao;

public class Atividade2810 {

    public static void main(String[] args) {
        Conexao c = new Conexao();
        c.getConexao();
    }
}

