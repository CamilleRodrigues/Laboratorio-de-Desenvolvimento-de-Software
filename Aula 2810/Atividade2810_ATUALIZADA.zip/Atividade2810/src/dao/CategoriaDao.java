package dao;
import beans.Categoria;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import atividade2810.conexao.Conexao;

public class CategoriaDao {
    Conexao conexao;
    Connection conn;
    
    public CategoriaDao() {
        this.conexao = new Conexao();
        this.conn = conexao.getConexao();
    }
    
    public void inserir(Categoria categorias) {
        String sql = "INSERT INTO categorias (nome) VALUES (?)";
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, categorias.getNome());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            System.out.println("Erro ao inserir categoria: " + e.getMessage());
        }
    }
    
    public Categoria getCategoria(int id) {
        String sql = "SELECT * FROM categorias WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            if (!rs.first()) {
                rs.close();
                stmt.close();
                return null;
            }
            
            Categoria c = new Categoria();
            c.setId(id);
            c.setNome(rs.getString("nome"));
            
            rs.close();
            stmt.close();
            return c;
        } catch(SQLException ex) {
            System.out.println("Erro ao consultar categoria: " + ex.getMessage());
            return null;
        }
    }
    
    public void editar(Categoria categorias) {
        try {
            String sql = "UPDATE categorias SET nome = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, categorias.getNome());
            stmt.setInt(2, categorias.getId()); // CORRIGIDO: mudado de 4 para 2
            stmt.execute();
            stmt.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar categoria: " + ex.getMessage());
        }
    }
    
    public List<Categoria> getCategoria() {
        String sql = "SELECT * FROM categorias";
        
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            List<Categoria> listaCategorias = new ArrayList();
            
            while(rs.next()) {
                Categoria c = new Categoria();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                listaCategorias.add(c);
            }
            rs.close();
            stmt.close();
            return listaCategorias;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todas as categorias: " + ex.getMessage());
            return null;
        }
    }
}