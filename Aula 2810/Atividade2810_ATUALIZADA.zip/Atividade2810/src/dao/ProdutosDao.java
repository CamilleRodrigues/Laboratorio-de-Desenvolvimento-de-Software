package dao;
import beans.Categoria;
import beans.Produtos;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import atividade2810.conexao.Conexao;

public class ProdutosDao {
    private final Conexao conexao;
    private final Connection conn;

    public ProdutosDao() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public void inserir(Produtos produtos) {
        String sql = "INSERT INTO produtos (nome, preco, quantidade, categoria_id) VALUES (?, ?, ?, ?)";

        if (conn == null) {
            System.out.println("Não foi possível conectar ao banco.");
            return;
        }
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, produtos.getNome());
            stmt.setDouble(2, produtos.getPreco());
            stmt.setInt(3, produtos.getQuantidade());
            stmt.setInt(4, produtos.getCategoria_id().getId());

            stmt.executeUpdate();

            System.out.println("Produto cadastrado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao inserir produto: " + e.getMessage());
        }
    }

    public void editar(Produtos produtos) {
        String sql = "UPDATE produtos SET nome = ?, preco = ?, quantidade = ?, categoria_id = ? WHERE id = ?";

        if (conn == null) {
            System.out.println("Não foi possível conectar ao banco.");
            return;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, produtos.getNome());
            stmt.setDouble(2, produtos.getPreco());
            stmt.setInt(3, produtos.getQuantidade());
            stmt.setInt(4, produtos.getCategoria_id().getId());
            stmt.setInt(5, produtos.getId());

            stmt.executeUpdate();

            System.out.println("Produto atualizado com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar produto: " + e.getMessage());
        }
    }

    public void excluir(int id) {
        String sql = "DELETE FROM produtos WHERE id = ?";

        if (conn == null) {
            System.out.println("Não foi possível conectar ao banco.");
            return;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            
            stmt.executeUpdate();

            System.out.println("Produto excluído com sucesso!");
        } catch (SQLException e) {
            System.out.println("Erro ao excluir produto: " + e.getMessage());
        }
    }

    private Produtos mapearProduto(ResultSet rs) throws SQLException {
        Produtos p = new Produtos();

        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setPreco(rs.getDouble("preco"));
        p.setQuantidade(rs.getInt("quantidade"));

        Categoria c = new Categoria();

        c.setId(rs.getInt("categoriaID"));
        c.setNome(rs.getString("categoriaNOME"));

        p.setCategoria_id(c);

        return p;
    }

    public List<Produtos> getProdutos() {
        List<Produtos> listaProdutos = new ArrayList<>();
        String sql = "SELECT p.*, c.id AS categoriaID, c.nome AS categoriaNOME FROM produtos p INNER JOIN categorias c ON p.categoria_id = c.id";

        if (conn == null) {
            return listaProdutos;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                listaProdutos.add(mapearProduto(rs));
            }
        } catch (SQLException e) {
            System.out.println("Erro ao consultar produtos: " + e.getMessage());
        }

        return listaProdutos;
    }

    public Produtos getProdutoPorId(int id) {
        String sql = "SELECT p.*, c.id AS categoriaID, c.nome AS categoriaNOME FROM produtos p INNER JOIN categorias c ON p.categoria_id = c.id WHERE p.id = ?";

        if (conn == null) {
            return null;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearProduto(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao consultar produto por ID: " + e.getMessage());
        }

        return null;
    }

    public Produtos getProdutoPorNome(String nome) {
        String sql = "SELECT p.*, c.id AS categoriaID, c.nome AS categoriaNOME FROM produtos p INNER JOIN categorias c ON p.categoria_id = c.id WHERE p.nome LIKE ? ORDER BY p.id LIMIT 1";

        if (conn == null || nome == null || nome.trim().isEmpty()) {
            return null;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + nome.trim() + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearProduto(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao consultar produto por nome: " + e.getMessage());
        }
        return null;
    }

    public List<Produtos> getProdutosPorCategoria(int categoriaId) {
        List<Produtos> listaProdutos = new ArrayList<>();
        String sql = "SELECT p.*, c.id AS categoriaID, c.nome AS categoriaNOME FROM produtos p INNER JOIN categorias c ON p.categoria_id = c.id WHERE c.id = ?";

        if (conn == null) {
            return listaProdutos;
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, categoriaId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    listaProdutos.add(mapearProduto(rs));
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro ao consultar produtos por categoria: "
                    + e.getMessage());
        }

        return listaProdutos;
    }
}
