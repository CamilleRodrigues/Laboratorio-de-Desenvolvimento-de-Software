package view;
import beans.Categoria;
import beans.Produtos;
import dao.CategoriaDao;
import dao.ProdutosDao;
import java.util.List;
import javax.swing.JOptionPane;

public final class FormEditarExcluirConsultarProdutos extends javax.swing.JFrame {

    private boolean atualizandoFormulario = false;

    public FormEditarExcluirConsultarProdutos() {
        initComponents();
        preencherComboCategoria();

        cmbCategoria.addActionListener(
            e -> {
                if (!atualizandoFormulario) {
                    limparCamposProduto();
                }
            }
        );
    }

    public void preencherComboCategoria() {
        CategoriaDao cDao = new CategoriaDao();
        List<Categoria> listaCategoria = cDao.getCategoria();

        for (Categoria c : listaCategoria) {
            cmbCategoria.addItem(c);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblPreco = new javax.swing.JLabel();
        txtPreco = new javax.swing.JTextField();
        lblQuantidade = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        lblCategoria = new javax.swing.JLabel();
        cmbCategoria = new javax.swing.JComboBox();
        btnConsultar = new javax.swing.JButton();
        txtID = new javax.swing.JTextField();
        lblID = new javax.swing.JLabel();
        btnEditar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblTitulo.setText("CONSULTA, EDIÇÃO E EXCLUSÃO DE PRODUTOS:");

        lblNome.setText("NOME:");

        lblPreco.setText("PREÇO:");

        lblQuantidade.setText("QUANTIDADE:");

        lblCategoria.setText("CATEGORIA:");

        btnConsultar.setText("CONSULTAR");
        btnConsultar.addActionListener(this::btnConsultarActionPerformed);

        lblID.setText("ID:");

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(this::btnEditarActionPerformed);

        btnExcluir.setText("EXCLUIR");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEditar)
                        .addGap(153, 153, 153)
                        .addComponent(btnExcluir)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTitulo)
                            .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(59, Short.MAX_VALUE))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGap(511, 511, 511)
                            .addComponent(btnConsultar))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(lblCategoria)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(cmbCategoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(lblQuantidade)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtQuantidade))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(lblPreco)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtPreco))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(lblNome)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(0, 0, Short.MAX_VALUE)))
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(lblTitulo)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblID)
                    .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 186, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditar)
                    .addComponent(btnExcluir))
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(100, 100, 100)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblNome)
                        .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblPreco)
                        .addComponent(txtPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblQuantidade)
                        .addComponent(txtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCategoria)
                        .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                    .addComponent(btnConsultar)
                    .addGap(10, 10, 10)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        try {
            if (txtID.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Consulte um produto antes de editar!");
                return;
            }
            if (txtNome.getText().trim().isEmpty() || txtPreco.getText().trim().isEmpty() || txtQuantidade.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
                return;
            }

            Categoria categoriaSelecionada = (Categoria) cmbCategoria.getSelectedItem();

            if (categoriaSelecionada == null) {
                JOptionPane.showMessageDialog(this, "Selecione uma categoria!");
                return;
            }

            double preco = Double.parseDouble(txtPreco.getText().trim().replace(",", "."));
            int quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            if (preco < 0 || quantidade < 0) {
                JOptionPane.showMessageDialog(this, "Preço e quantidade não podem ser negativos!");
                return;
            }

            Produtos p = new Produtos();

            p.setId(Integer.parseInt(txtID.getText()));
            p.setNome(txtNome.getText().trim());
            p.setPreco(preco);
            p.setQuantidade(quantidade);
            p.setCategoria_id(categoriaSelecionada);

            ProdutosDao pDAO = new ProdutosDao();
            pDAO.editar(p);

            JOptionPane.showMessageDialog(this, "Atualização realizada!");
            limparFormulario();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Verifique os valores informados!");
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
        ProdutosDao pDAO = new ProdutosDao();
        Produtos p = null;

        String idTexto = txtID.getText().trim();
        String nomeTexto = txtNome.getText().trim();

        Categoria categoriaSelecionada = (Categoria) cmbCategoria.getSelectedItem();

        if (!idTexto.isEmpty()) {
            try {
                int id = Integer.parseInt(idTexto);
                p = pDAO.getProdutoPorId(id);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Informe um ID válido!");
                return;
            }
        } else if (!nomeTexto.isEmpty()) {
            p = pDAO.getProdutoPorNome(nomeTexto);
        } else if (categoriaSelecionada != null) {
            List<Produtos> lista = pDAO.getProdutosPorCategoria(categoriaSelecionada.getId());
            if (!lista.isEmpty()) {
                p = lista.get(0);
            }
        }

        if (p == null) {
            limparCamposProduto();
            JOptionPane.showMessageDialog(this, "Nenhum produto encontrado para a pesquisa realizada!");
            return;
        }

        atualizandoFormulario = true;
        txtID.setText(String.valueOf(p.getId()));
        txtNome.setText(p.getNome());
        txtPreco.setText(String.valueOf(p.getPreco()));
        txtQuantidade.setText(String.valueOf(p.getQuantidade()));
        cmbCategoria.setSelectedItem(p.getCategoria_id());
        atualizandoFormulario = false;
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        if (txtID.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Consulte um produto antes de excluir!");
            return;
        }

        int resposta = JOptionPane.showConfirmDialog(this, "Deseja realmente excluir este produto?", "Exclusão", JOptionPane.YES_NO_OPTION);

        if (resposta == JOptionPane.YES_OPTION) {
            ProdutosDao pDAO = new ProdutosDao();
            pDAO.excluir(Integer.parseInt(txtID.getText()));
            limparFormulario();
            JOptionPane.showMessageDialog(this, "Produto excluído com sucesso!");
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void limparCamposProduto() {
        txtID.setText("");
        txtNome.setText("");
        txtPreco.setText("");
        txtQuantidade.setText("");
    }

    private void limparFormulario() {
        atualizandoFormulario = true;
        limparCamposProduto();
        if (cmbCategoria.getItemCount() > 0) {
            cmbCategoria.setSelectedIndex(0);
        }
        atualizandoFormulario = false;
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new FormEditarExcluirConsultarProdutos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JComboBox cmbCategoria;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblPreco;
    private javax.swing.JLabel lblQuantidade;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtPreco;
    private javax.swing.JTextField txtQuantidade;
    // End of variables declaration//GEN-END:variables
}
