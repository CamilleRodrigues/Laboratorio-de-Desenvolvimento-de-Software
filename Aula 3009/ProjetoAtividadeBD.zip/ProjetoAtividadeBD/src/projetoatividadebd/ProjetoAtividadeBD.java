package projetoatividadebd;
import beans.Aluno;
import beans.Professor;
import dao.AlunoDao;
import dao.ProfessorDao;
import projetoatividadebd.conexao.Conexao;

public class ProjetoAtividadeBD {
    public static void main(String[] args) {
        Conexao c = new Conexao();
        c.getConexao();
        Aluno a = new Aluno();
        a.setNome("Camille Rodrigues");
        a.setIdade("24");
        a.setCurso("Sistemas de Informação");
        AlunoDao adao = new AlunoDao();
        adao.inserir(a);
        Professor p = new Professor();
        p.setNome("Ana Paula");
        p.setIdade("30");
        p.setDisciplina("Fundamentos de Linguagens Formais");
        ProfessorDao pdao = new ProfessorDao();
        pdao.inserir(p);
    }
}
