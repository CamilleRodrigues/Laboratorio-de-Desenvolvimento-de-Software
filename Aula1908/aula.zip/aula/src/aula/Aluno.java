/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula;

/**
 *
 * @author laboratorio
 */
public class Aluno {
    public String nome;
    public String datanascimento;
    public char sexo;
    public String matricula;
    public String curso;
    public String cpf;
    public String rua;
    public String número;
    public String bairro;
    public String cidade;
    public String cep;
    public String estado; 
    public String telefone;

    public Aluno(String nome, String datanascimento, char sexo, String matricula, String curso, String cpf, String rua, String número, String bairro, String cidade, String cep, String estado, String telefone) {
        this.nome = nome;
        this.datanascimento = datanascimento;
        this.sexo = sexo;
        this.matricula = matricula;
        this.curso = curso;
        this.cpf = cpf;
        this.rua = rua;
        this.número = número;
        this.bairro = bairro;
        this.cidade = cidade;
        this.cep = cep;
        this.estado = estado;
        this.telefone = telefone;
    }
    
    @Override
    public String toString() {
        return nome + ";" + datanascimento + ";" + sexo + ";" + matricula + ";" + curso + ";" + cpf + ";" + rua + ";" + número + ";" + bairro + ";" + cidade + ";" + cep + ";" + estado + ";" + telefone;
    }
    
    

}
